import React from 'react';
import { useAuth } from '../context/AuthContext';
import Card from '../components/ui/Card';
import AttendanceCard from '../components/dashboard/AttendanceCard';
import HomeworkCard from '../components/dashboard/HomeworkCard';
import ExamCard from '../components/dashboard/ExamCard';
import { attendance, homework, exams } from '../data/mockData';
import { Calendar, Clock } from 'lucide-react';

const DashboardPage: React.FC = () => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return null; // Or a loading state, or redirect
  }
  
  // Get current date and time
  const currentDate = new Date();
  const formattedDate = currentDate.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  
  const formattedTime = currentDate.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
  
  return (
    <div className="bg-gray-50 min-h-screen pb-12">
      {/* Hero section */}
      <div className="bg-blue-800 text-white py-8 px-4 sm:px-6 lg:px-8 rounded-b-3xl shadow-md">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">Welcome, {currentUser.name}!</h1>
              <div className="flex items-center mt-2 text-blue-100">
                <Calendar size={16} className="mr-1" />
                <span className="mr-4">{formattedDate}</span>
                <Clock size={16} className="mr-1" />
                <span>{formattedTime}</span>
              </div>
            </div>
            <div className="mt-4 md:mt-0">
              <div className="inline-block bg-white/10 backdrop-blur-sm rounded-lg px-4 py-2">
                <span className="text-sm">Role: </span>
                <span className="text-sm font-medium">
                  {currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Dashboard grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Attendance Card */}
          <AttendanceCard attendance={attendance} />
          
          {/* Homework Card */}
          <HomeworkCard homework={homework} />
          
          {/* Exams Card */}
          <ExamCard exams={exams} />
          
          {/* Quick Links Card */}
          <Card title="Quick Links" className="lg:col-span-3">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[
                { title: 'Timetable', color: 'bg-blue-100 text-blue-800' },
                { title: 'Grades', color: 'bg-green-100 text-green-800' },
                { title: 'Library', color: 'bg-amber-100 text-amber-800' },
                { title: 'Calendar', color: 'bg-purple-100 text-purple-800' },
                { title: 'Resources', color: 'bg-teal-100 text-teal-800' },
                { title: 'Support', color: 'bg-red-100 text-red-800' },
              ].map((link, index) => (
                <a 
                  key={index} 
                  href="#" 
                  className={`${link.color} p-4 rounded-lg text-center transition-transform hover:scale-105`}
                >
                  {link.title}
                </a>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
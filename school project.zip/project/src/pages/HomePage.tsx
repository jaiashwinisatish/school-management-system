import React from 'react';
import HeroSection from '../components/home/HeroSection';
import AnnouncementSection from '../components/home/AnnouncementSection';
import EventsSection from '../components/home/EventsSection';
import StatisticsSection from '../components/home/StatisticsSection';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <HeroSection />
      <AnnouncementSection />
      <StatisticsSection />
      <EventsSection />
    </div>
  );
};

export default HomePage;
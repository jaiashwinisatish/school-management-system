import React, { ReactNode } from 'react';

interface BadgeProps {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'default';
  size?: 'sm' | 'md' | 'lg';
  rounded?: boolean;
  className?: string;
}

const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'default',
  size = 'md',
  rounded = false,
  className = '',
}) => {
  // Base styles
  const baseStyle = 'inline-flex items-center font-medium';
  
  // Size variations
  const sizeStyles = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-0.5 text-sm',
    lg: 'px-3 py-1 text-base',
  };
  
  // Variant styles
  const variantStyles = {
    primary: 'bg-blue-100 text-blue-800',
    secondary: 'bg-teal-100 text-teal-800',
    success: 'bg-green-100 text-green-800',
    warning: 'bg-amber-100 text-amber-800',
    error: 'bg-red-100 text-red-800',
    default: 'bg-gray-100 text-gray-800',
  };
  
  // Border radius
  const radiusStyle = rounded ? 'rounded-full' : 'rounded-md';
  
  // Combine all styles
  const allStyles = `${baseStyle} ${sizeStyles[size]} ${variantStyles[variant]} ${radiusStyle} ${className}`;
  
  return <span className={allStyles}>{children}</span>;
};

export default Badge;
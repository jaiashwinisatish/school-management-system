import React from 'react';

interface AvatarProps {
  src?: string;
  alt?: string;
  name?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  status?: 'online' | 'away' | 'busy' | 'offline';
}

const Avatar: React.FC<AvatarProps> = ({
  src,
  alt = 'Avatar',
  name,
  size = 'md',
  className = '',
  status,
}) => {
  // Size classes
  const sizeClasses = {
    xs: 'w-6 h-6 text-xs',
    sm: 'w-8 h-8 text-sm',
    md: 'w-10 h-10 text-base',
    lg: 'w-12 h-12 text-lg',
    xl: 'w-16 h-16 text-xl',
  };

  // Status classes
  const statusClasses = {
    online: 'bg-green-500',
    away: 'bg-yellow-500',
    busy: 'bg-red-500',
    offline: 'bg-gray-500',
  };

  // Get initials from name
  const getInitials = () => {
    if (!name) return '?';
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  // Base classes
  const baseClasses = `relative inline-flex items-center justify-center rounded-full bg-gray-200 ${sizeClasses[size]} ${className}`;

  return (
    <div className={baseClasses}>
      {src ? (
        <img
          src={src}
          alt={alt}
          className="w-full h-full object-cover rounded-full"
        />
      ) : (
        <span className="font-medium text-gray-600">{getInitials()}</span>
      )}
      
      {status && (
        <span 
          className={`absolute bottom-0 right-0 block rounded-full ring-2 ring-white ${statusClasses[status]}`} 
          style={{
            width: size === 'xs' ? '0.5rem' : size === 'sm' ? '0.625rem' : '0.75rem',
            height: size === 'xs' ? '0.5rem' : size === 'sm' ? '0.625rem' : '0.75rem',
          }}
        />
      )}
    </div>
  );
};

export default Avatar;
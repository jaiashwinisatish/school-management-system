import React, { ReactNode } from 'react';

interface CardProps {
  title?: string;
  subtitle?: string;
  icon?: ReactNode;
  children: ReactNode;
  className?: string;
  footer?: ReactNode;
  onCardClick?: () => void;
}

const Card: React.FC<CardProps> = ({
  title,
  subtitle,
  icon,
  children,
  className = '',
  footer,
  onCardClick,
}) => {
  const cardClasses = `bg-white rounded-lg shadow-md overflow-hidden transition-all duration-200 ${
    onCardClick ? 'cursor-pointer hover:shadow-lg transform hover:-translate-y-1' : ''
  } ${className}`;

  return (
    <div className={cardClasses} onClick={onCardClick}>
      {(title || icon) && (
        <div className="px-6 py-4 border-b border-gray-100">
          <div className="flex items-center">
            {icon && <div className="mr-3 text-blue-800">{icon}</div>}
            <div>
              {title && <h3 className="text-lg font-semibold text-gray-800">{title}</h3>}
              {subtitle && <p className="text-sm text-gray-500">{subtitle}</p>}
            </div>
          </div>
        </div>
      )}
      <div className="px-6 py-4">{children}</div>
      {footer && <div className="px-6 py-3 bg-gray-50 border-t border-gray-100">{footer}</div>}
    </div>
  );
};

export default Card;
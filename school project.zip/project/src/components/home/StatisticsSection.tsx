import React from 'react';
import { Users, Award, BookOpen, Medal } from 'lucide-react';

interface StatProps {
  icon: React.ReactNode;
  value: string;
  label: string;
  delay?: number;
}

const Stat: React.FC<StatProps> = ({ icon, value, label, delay = 0 }) => {
  return (
    <div 
      className="flex flex-col items-center p-6 bg-white rounded-lg shadow-md transition-transform hover:transform hover:scale-105"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="text-blue-800 mb-4">{icon}</div>
      <div className="text-3xl font-bold mb-1 text-gray-900">{value}</div>
      <div className="text-sm text-gray-600 text-center">{label}</div>
    </div>
  );
};

const StatisticsSection: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-blue-800 to-blue-900 text-white relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%">
          <pattern id="dots" width="20" height="20" patternUnits="userSpaceOnUse">
            <circle cx="10" cy="10" r="2" fill="currentColor" />
          </pattern>
          <rect width="100%" height="100%" fill="url(#dots)" />
        </svg>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-2">Excellence in Numbers</h2>
          <p className="max-w-2xl mx-auto opacity-80">
            Westfield Academy has a proven track record of academic excellence and student success.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <Stat 
            icon={<Users size={36} />} 
            value="1,500+" 
            label="Students Currently Enrolled"
            delay={0}
          />
          <Stat 
            icon={<Award size={36} />} 
            value="98%" 
            label="Graduation Rate"
            delay={200}
          />
          <Stat 
            icon={<BookOpen size={36} />} 
            value="45+" 
            label="Advanced Courses Offered"
            delay={400}
          />
          <Stat 
            icon={<Medal size={36} />} 
            value="250+" 
            label="Awards & Honors Received"
            delay={600}
          />
        </div>
      </div>
    </section>
  );
};

export default StatisticsSection;
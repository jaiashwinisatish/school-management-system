import React from 'react';
import { Bell, ArrowRight } from 'lucide-react';
import { announcements } from '../../data/mockData';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import { Link } from 'react-router-dom';

const AnnouncementSection: React.FC = () => {
  // Format date
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Latest Announcements</h2>
            <p className="text-gray-600 max-w-2xl">
              Stay updated with the latest news and important announcements from Westfield Academy.
            </p>
          </div>
          <Link 
            to="/announcements" 
            className="inline-flex items-center mt-4 md:mt-0 text-blue-800 hover:text-blue-700 font-medium"
          >
            View all announcements
            <ArrowRight size={16} className="ml-1" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {announcements.map((announcement) => (
            <Card 
              key={announcement.id}
              className={`h-full transition-all duration-300 hover:shadow-lg ${
                announcement.important ? 'border-l-4 border-amber-400' : ''
              }`}
              onCardClick={() => {}}
            >
              <div className="flex flex-col h-full">
                <div className="flex justify-between items-start mb-3">
                  <span className="text-gray-500 text-sm">{formatDate(announcement.date)}</span>
                  {announcement.important && (
                    <Badge variant="warning" rounded>Important</Badge>
                  )}
                </div>
                <h3 className="text-lg font-semibold mb-2 text-gray-900">{announcement.title}</h3>
                <p className="text-gray-600 text-sm mb-4 flex-grow line-clamp-3">
                  {announcement.content}
                </p>
                <div className="mt-auto pt-4 border-t border-gray-100 text-sm text-gray-500">
                  By {announcement.author}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AnnouncementSection;
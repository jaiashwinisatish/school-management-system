import React from 'react';
import { Calendar, MapPin, Clock, ArrowRight } from 'lucide-react';
import { events } from '../../data/mockData';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import { Link } from 'react-router-dom';

const EventsSection: React.FC = () => {
  // Format date
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  // Get event type badge variant
  const getEventTypeVariant = (type: string) => {
    switch (type) {
      case 'academic':
        return 'primary';
      case 'sports':
        return 'success';
      case 'cultural':
        return 'secondary';
      default:
        return 'default';
    }
  };

  // Capitalize first letter
  const capitalizeFirstLetter = (string: string) => {
    return string.charAt(0).toUpperCase() + string.slice(1);
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Upcoming Events</h2>
            <p className="text-gray-600 max-w-2xl">
              Explore upcoming events, activities, and competitions at Westfield Academy.
            </p>
          </div>
          <Link 
            to="/events" 
            className="inline-flex items-center mt-4 md:mt-0 text-blue-800 hover:text-blue-700 font-medium"
          >
            View all events
            <ArrowRight size={16} className="ml-1" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {events.map((event) => (
            <Card 
              key={event.id}
              className="h-full transition-all duration-300 hover:shadow-lg overflow-hidden"
              onCardClick={() => {}}
            >
              <div className="flex flex-col md:flex-row h-full">
                <div className="md:w-1/3 bg-blue-50 flex flex-col items-center justify-center p-6 text-center">
                  <div className="text-3xl font-bold text-blue-800">
                    {new Date(event.date).getDate()}
                  </div>
                  <div className="text-lg text-blue-800">
                    {new Date(event.date).toLocaleString('default', { month: 'short' })}
                  </div>
                  <div className="text-gray-500 mt-2 text-sm">
                    {new Date(event.date).getFullYear()}
                  </div>
                  <Badge 
                    variant={getEventTypeVariant(event.type)} 
                    className="mt-4"
                  >
                    {capitalizeFirstLetter(event.type)}
                  </Badge>
                </div>
                <div className="md:w-2/3 p-6">
                  <h3 className="text-lg font-semibold mb-2 text-gray-900">{event.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">
                    {event.description}
                  </p>
                  <div className="mt-4 space-y-2 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Clock size={16} className="mr-2 text-gray-400" />
                      {event.time}
                    </div>
                    <div className="flex items-center">
                      <MapPin size={16} className="mr-2 text-gray-400" />
                      {event.location}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EventsSection;
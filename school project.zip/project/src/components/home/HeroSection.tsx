import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../ui/Button';

const HeroSection: React.FC = () => {
  return (
    <div className="relative bg-blue-800 text-white overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <pattern id="grid" width="8" height="8" patternUnits="userSpaceOnUse">
              <path d="M 8 0 L 0 0 0 8" fill="none" stroke="currentColor" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100" height="100" fill="url(#grid)" />
        </svg>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 relative z-10">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
          <div className="mb-12 lg:mb-0">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6 animate-fade-in">
              Shaping Tomorrow's
              <span className="block text-blue-300">Leaders Today</span>
            </h1>
            <p className="text-lg sm:text-xl mb-8 max-w-lg opacity-90">
              At Westfield Academy, we combine academic excellence with character development to prepare students for success in a rapidly changing world.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/about">
                <Button size="lg">Learn More</Button>
              </Link>
              <Link to="/signup">
                <Button variant="outline" size="lg" className="bg-blue-700 hover:bg-blue-600 text-white border-0">
                  Enroll Now
                </Button>
              </Link>
            </div>
          </div>
          <div className="relative">
            <div className="rounded-lg overflow-hidden shadow-2xl transform transition-transform hover:scale-[1.02]">
              <img
                src="https://images.pexels.com/photos/8617741/pexels-photo-8617741.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"
                alt="Students in a classroom"
                className="w-full h-auto"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-teal-600 rounded-lg shadow-lg p-6 max-w-xs">
              <p className="font-semibold text-lg mb-1">Admissions Open</p>
              <p className="text-sm opacity-90">For the upcoming academic year 2025-2026</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
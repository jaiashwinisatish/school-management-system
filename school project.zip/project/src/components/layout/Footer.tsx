import React from 'react';
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';
import { schoolInfo } from '../../data/mockData';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-blue-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* School Info */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Westfield Academy</h2>
            <div className="space-y-2">
              <p className="flex items-start">
                <MapPin size={18} className="mr-2 mt-1 flex-shrink-0" />
                <span>{schoolInfo.address}</span>
              </p>
              <p className="flex items-center">
                <Phone size={18} className="mr-2 flex-shrink-0" />
                <span>{schoolInfo.phone}</span>
              </p>
              <p className="flex items-center">
                <Mail size={18} className="mr-2 flex-shrink-0" />
                <span>{schoolInfo.email}</span>
              </p>
            </div>
            <div className="mt-4 flex space-x-4">
              <a href={schoolInfo.socialMedia.facebook} className="hover:text-blue-300 transition-colors" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href={schoolInfo.socialMedia.twitter} className="hover:text-blue-300 transition-colors" aria-label="Twitter">
                <Twitter size={20} />
              </a>
              <a href={schoolInfo.socialMedia.instagram} className="hover:text-blue-300 transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Quick Links</h2>
            <ul className="space-y-2">
              <li>
                <a href="/" className="hover:text-blue-300 transition-colors">Home</a>
              </li>
              <li>
                <a href="/events" className="hover:text-blue-300 transition-colors">Events</a>
              </li>
              <li>
                <a href="/about" className="hover:text-blue-300 transition-colors">About Us</a>
              </li>
              <li>
                <a href="/contact" className="hover:text-blue-300 transition-colors">Contact</a>
              </li>
              <li>
                <a href="/careers" className="hover:text-blue-300 transition-colors">Careers</a>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Resources</h2>
            <ul className="space-y-2">
              <li>
                <a href="/calendar" className="hover:text-blue-300 transition-colors">Academic Calendar</a>
              </li>
              <li>
                <a href="/library" className="hover:text-blue-300 transition-colors">Library</a>
              </li>
              <li>
                <a href="/scholarships" className="hover:text-blue-300 transition-colors">Scholarships</a>
              </li>
              <li>
                <a href="/parent-portal" className="hover:text-blue-300 transition-colors">Parent Portal</a>
              </li>
              <li>
                <a href="/faq" className="hover:text-blue-300 transition-colors">FAQ</a>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Stay Updated</h2>
            <p className="mb-4">Subscribe to our newsletter for the latest news and updates.</p>
            <form className="flex flex-col space-y-2">
              <input
                type="email"
                placeholder="Enter your email"
                className="px-4 py-2 text-gray-800 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="bg-blue-700 hover:bg-blue-600 text-white py-2 px-4 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-blue-800 text-center text-sm">
          <p>&copy; {currentYear} Westfield Academy. All rights reserved.</p>
          <div className="mt-2 space-x-4">
            <a href="/privacy" className="hover:text-blue-300 transition-colors">Privacy Policy</a>
            <a href="/terms" className="hover:text-blue-300 transition-colors">Terms of Service</a>
            <a href="/accessibility" className="hover:text-blue-300 transition-colors">Accessibility</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
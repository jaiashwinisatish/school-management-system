import React from 'react';
import { Calendar, Check, X, Clock } from 'lucide-react';
import Card from '../ui/Card';
import { Attendance } from '../../types';

interface AttendanceCardProps {
  attendance: Attendance[];
}

const AttendanceCard: React.FC<AttendanceCardProps> = ({ attendance }) => {
  // Calculate attendance stats
  const totalDays = attendance.length;
  const presentDays = attendance.filter(day => day.status === 'present').length;
  const absentDays = attendance.filter(day => day.status === 'absent').length;
  const lateDays = attendance.filter(day => day.status === 'late').length;
  
  const attendancePercentage = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 0;

  // Format date function
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  return (
    <Card title="Attendance Overview" icon={<Calendar size={20} />}>
      <div className="flex flex-col">
        <div className="flex justify-between items-center mb-4">
          <div className="text-sm text-gray-600">This Month</div>
          <div className="text-sm text-gray-600">
            Present: {presentDays}/{totalDays} days
          </div>
        </div>
        
        {/* Attendance Percentage Circle */}
        <div className="flex justify-center mb-6">
          <div className="relative inline-flex items-center justify-center">
            <svg className="w-24 h-24">
              <circle
                className="text-gray-200"
                strokeWidth="6"
                stroke="currentColor"
                fill="transparent"
                r="36"
                cx="48"
                cy="48"
              />
              <circle
                className={`${
                  attendancePercentage >= 90
                    ? 'text-green-500'
                    : attendancePercentage >= 75
                    ? 'text-amber-500'
                    : 'text-red-500'
                }`}
                strokeWidth="6"
                strokeDasharray={36 * 2 * Math.PI}
                strokeDashoffset={36 * 2 * Math.PI * (1 - attendancePercentage / 100)}
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
                r="36"
                cx="48"
                cy="48"
              />
            </svg>
            <span className="absolute text-2xl font-semibold">{attendancePercentage}%</span>
          </div>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          <div className="bg-green-50 p-3 rounded-lg text-center">
            <div className="flex justify-center mb-1 text-green-500">
              <Check size={18} />
            </div>
            <div className="text-lg font-semibold text-gray-800">{presentDays}</div>
            <div className="text-xs text-gray-600">Present</div>
          </div>
          <div className="bg-red-50 p-3 rounded-lg text-center">
            <div className="flex justify-center mb-1 text-red-500">
              <X size={18} />
            </div>
            <div className="text-lg font-semibold text-gray-800">{absentDays}</div>
            <div className="text-xs text-gray-600">Absent</div>
          </div>
          <div className="bg-amber-50 p-3 rounded-lg text-center">
            <div className="flex justify-center mb-1 text-amber-500">
              <Clock size={18} />
            </div>
            <div className="text-lg font-semibold text-gray-800">{lateDays}</div>
            <div className="text-xs text-gray-600">Late</div>
          </div>
        </div>
        
        {/* Recent attendance log */}
        <h4 className="text-sm font-semibold text-gray-700 mb-2">Recent Attendance</h4>
        <div className="space-y-2">
          {attendance.slice(0, 5).map((day, index) => (
            <div key={index} className="flex justify-between items-center p-2 rounded-md hover:bg-gray-50">
              <div className="flex items-center">
                <div className={`w-2 h-2 rounded-full mr-2 ${
                  day.status === 'present' ? 'bg-green-500' : 
                  day.status === 'absent' ? 'bg-red-500' : 'bg-amber-500'
                }`}></div>
                <span className="text-sm">{formatDate(day.date)}</span>
              </div>
              <div className="flex items-center">
                {day.subject && <span className="text-xs text-gray-500 mr-2">{day.subject}</span>}
                <span className={`text-xs px-2 py-1 rounded-full ${
                  day.status === 'present' ? 'bg-green-100 text-green-800' : 
                  day.status === 'absent' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                }`}>
                  {day.status.charAt(0).toUpperCase() + day.status.slice(1)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
};

export default AttendanceCard;
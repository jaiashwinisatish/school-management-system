import React from 'react';
import { Book, Calendar, Clock, CheckCircle } from 'lucide-react';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import { Homework } from '../../types';
import { Link } from 'react-router-dom';

interface HomeworkCardProps {
  homework: Homework[];
}

const HomeworkCard: React.FC<HomeworkCardProps> = ({ homework }) => {
  // Sort homework by due date (closest first)
  const sortedHomework = [...homework].sort((a, b) => 
    new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
  );
  
  // Upcoming homework (not submitted)
  const upcomingHomework = sortedHomework.filter(hw => !hw.submitted);
  
  // Format date
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };
  
  // Calculate days remaining
  const getDaysRemaining = (dueDate: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);
    
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  return (
    <Card 
      title="Homework & Assignments" 
      icon={<Book size={20} />}
      footer={
        <Link to="/homework" className="text-blue-800 hover:text-blue-700 text-sm font-medium">
          View all assignments
        </Link>
      }
    >
      <div className="space-y-4">
        {upcomingHomework.length > 0 ? (
          upcomingHomework.slice(0, 3).map((hw) => {
            const daysRemaining = getDaysRemaining(hw.dueDate);
            
            return (
              <div key={hw.id} className="border border-gray-100 rounded-lg p-3 hover:bg-gray-50 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <Badge
                    variant="primary"
                    size="sm"
                    className="font-normal"
                  >
                    {hw.subject}
                  </Badge>
                  <Badge
                    variant={daysRemaining <= 1 ? 'error' : daysRemaining <= 3 ? 'warning' : 'success'}
                    size="sm"
                    rounded
                  >
                    {daysRemaining === 0 
                      ? 'Due today' 
                      : daysRemaining < 0 
                        ? 'Overdue' 
                        : daysRemaining === 1 
                          ? 'Due tomorrow' 
                          : `${daysRemaining} days left`}
                  </Badge>
                </div>
                <h4 className="font-medium text-gray-800 mb-1">{hw.title}</h4>
                <p className="text-sm text-gray-600 line-clamp-2 mb-2">{hw.description}</p>
                <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                  <div className="flex items-center">
                    <Calendar size={14} className="mr-1" />
                    Due: {formatDate(hw.dueDate)}
                  </div>
                  <div>
                    {hw.assignedBy}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="py-8 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-green-100 text-green-600 rounded-full mb-3">
              <CheckCircle size={24} />
            </div>
            <p className="text-gray-600">You're all caught up! No pending assignments.</p>
          </div>
        )}
      </div>
    </Card>
  );
};

export default HomeworkCard;
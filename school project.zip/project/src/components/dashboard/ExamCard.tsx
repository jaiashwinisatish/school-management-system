import React from 'react';
import { FileText, Calendar, Clock, MapPin } from 'lucide-react';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import { Exam } from '../../types';
import { Link } from 'react-router-dom';

interface ExamCardProps {
  exams: Exam[];
}

const ExamCard: React.FC<ExamCardProps> = ({ exams }) => {
  // Sort exams by date (closest first)
  const sortedExams = [...exams].sort((a, b) => 
    new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  
  // Format date
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'short', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };
  
  // Calculate days remaining
  const getDaysRemaining = (examDate: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const date = new Date(examDate);
    date.setHours(0, 0, 0, 0);
    
    const diffTime = date.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  return (
    <Card 
      title="Upcoming Exams" 
      icon={<FileText size={20} />}
      footer={
        <Link to="/exams" className="text-blue-800 hover:text-blue-700 text-sm font-medium">
          View full exam schedule
        </Link>
      }
    >
      <div className="space-y-4">
        {sortedExams.slice(0, 3).map((exam) => {
          const daysRemaining = getDaysRemaining(exam.date);
          
          return (
            <div key={exam.id} className="border border-gray-100 rounded-lg p-3 hover:bg-gray-50 transition-colors">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-medium text-gray-800">{exam.subject} Exam</h4>
                <Badge
                  variant={daysRemaining <= 3 ? 'error' : daysRemaining <= 7 ? 'warning' : 'success'}
                  size="sm"
                  rounded
                >
                  {daysRemaining === 0 
                    ? 'Today' 
                    : daysRemaining === 1 
                      ? 'Tomorrow' 
                      : `${daysRemaining} days left`}
                </Badge>
              </div>
              
              <div className="grid grid-cols-2 gap-2 mt-3">
                <div className="flex items-center text-xs text-gray-600">
                  <Calendar size={14} className="mr-1 text-gray-400" />
                  {formatDate(exam.date)}
                </div>
                <div className="flex items-center text-xs text-gray-600">
                  <Clock size={14} className="mr-1 text-gray-400" />
                  {exam.time} ({exam.duration})
                </div>
                <div className="flex items-center text-xs text-gray-600 col-span-2">
                  <MapPin size={14} className="mr-1 text-gray-400" />
                  {exam.venue}
                </div>
              </div>
              
              {exam.topics && (
                <div className="mt-3">
                  <div className="text-xs text-gray-500 mb-1">Topics:</div>
                  <div className="flex flex-wrap gap-1">
                    {exam.topics.map((topic, idx) => (
                      <Badge key={idx} variant="default" size="sm" className="font-normal">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </Card>
  );
};

export default ExamCard;
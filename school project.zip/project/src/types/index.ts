export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'teacher' | 'admin';
  avatar?: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
  author: string;
  important?: boolean;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  type: 'academic' | 'sports' | 'cultural' | 'other';
}

export interface Homework {
  id: string;
  subject: string;
  title: string;
  description: string;
  dueDate: string;
  assignedBy: string;
  fileUrl?: string;
  submitted?: boolean;
}

export interface Exam {
  id: string;
  subject: string;
  date: string;
  time: string;
  duration: string;
  venue: string;
  topics?: string[];
}

export interface Attendance {
  date: string;
  status: 'present' | 'absent' | 'late';
  subject?: string;
}

export interface Student {
  id: string;
  name: string;
  grade: string;
  section: string;
  rollNumber: string;
  attendance: Attendance[];
  exams: Exam[];
  homework: Homework[];
}

export interface SchoolInfo {
  name: string;
  logo: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  socialMedia: {
    facebook?: string;
    twitter?: string;
    instagram?: string;
  };
}
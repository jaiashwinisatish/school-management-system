import { Announcement, Attendance, Event, Exam, Homework, SchoolInfo, User } from '../types';

export const schoolInfo: SchoolInfo = {
  name: 'Westfield Academy',
  logo: '/logo.svg',
  address: '123 Education Lane, Learning City, LC 12345',
  phone: '(555) 123-4567',
  email: 'info@westfieldacademy.edu',
  website: 'www.westfieldacademy.edu',
  socialMedia: {
    facebook: 'https://facebook.com/westfieldacademy',
    twitter: 'https://twitter.com/westfieldacad',
    instagram: 'https://instagram.com/westfieldacademy',
  },
};

export const users: User[] = [
  {
    id: '1',
    name: 'Alex Johnson',
    email: 'alex@example.com',
    role: 'student',
    avatar: 'https://images.pexels.com/photos/1462630/pexels-photo-1462630.jpeg?auto=compress&cs=tinysrgb&w=150',
  },
  {
    id: '2',
    name: 'Sarah Williams',
    email: 'sarah@example.com',
    role: 'teacher',
    avatar: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=150',
  },
  {
    id: '3',
    name: 'Michael Chen',
    email: 'michael@example.com',
    role: 'admin',
    avatar: 'https://images.pexels.com/photos/3771807/pexels-photo-3771807.jpeg?auto=compress&cs=tinysrgb&w=150',
  },
];

export const announcements: Announcement[] = [
  {
    id: '1',
    title: 'New Grading System Implementation',
    content: 'We are pleased to announce the implementation of a new grading system that will provide more detailed feedback to students. This system will be effective from the next academic term.',
    date: '2025-03-15',
    author: 'Principal Williams',
    important: true,
  },
  {
    id: '2',
    title: 'Parent-Teacher Conference',
    content: 'The annual parent-teacher conference will be held on April 5th. Please make arrangements to attend as this is an important opportunity to discuss your child\'s progress.',
    date: '2025-03-10',
    author: 'Vice Principal Johnson',
  },
  {
    id: '3',
    title: 'Campus Maintenance Notice',
    content: 'The east wing of the main building will be undergoing maintenance next week. Classes normally held in that area will be temporarily relocated.',
    date: '2025-03-08',
    author: 'Facilities Management',
  },
  {
    id: '4',
    title: 'Sports Day Announcement',
    content: 'The annual sports day will be held on May 12th. Students interested in participating should register with their physical education teachers by April 15th.',
    date: '2025-03-05',
    author: 'Sports Department',
  },
];

export const events: Event[] = [
  {
    id: '1',
    title: 'Science Fair',
    description: 'Annual science exhibition showcasing student projects from all grades. Prizes will be awarded for the most innovative projects.',
    date: '2025-04-20',
    time: '9:00 AM - 3:00 PM',
    location: 'Main Hall',
    type: 'academic',
  },
  {
    id: '2',
    title: 'Basketball Tournament',
    description: 'Inter-school basketball tournament. Our school will be hosting teams from five neighboring schools.',
    date: '2025-04-25',
    time: '1:00 PM - 5:00 PM',
    location: 'Sports Complex',
    type: 'sports',
  },
  {
    id: '3',
    title: 'Cultural Day',
    description: 'A celebration of diversity with performances, food, and displays representing various cultures from around the world.',
    date: '2025-05-05',
    time: '10:00 AM - 4:00 PM',
    location: 'School Grounds',
    type: 'cultural',
  },
  {
    id: '4',
    title: 'Career Guidance Workshop',
    description: 'Workshop for senior students with professionals from various fields sharing insights about career options and pathways.',
    date: '2025-05-10',
    time: '2:00 PM - 4:00 PM',
    location: 'Lecture Hall',
    type: 'academic',
  },
];

export const homework: Homework[] = [
  {
    id: '1',
    subject: 'Mathematics',
    title: 'Quadratic Equations',
    description: 'Complete exercises 5-10 on page 45 of the textbook. Show all your work and submit.',
    dueDate: '2025-03-20',
    assignedBy: 'Ms. Peterson',
  },
  {
    id: '2',
    subject: 'English Literature',
    title: 'Character Analysis',
    description: 'Write a 500-word analysis of the main character in the novel we are currently studying.',
    dueDate: '2025-03-22',
    assignedBy: 'Mr. Thompson',
  },
  {
    id: '3',
    subject: 'Physics',
    title: 'Newton\'s Laws of Motion',
    description: 'Prepare a presentation explaining Newton\'s three laws of motion with real-world examples.',
    dueDate: '2025-03-25',
    assignedBy: 'Dr. Richards',
  },
  {
    id: '4',
    subject: 'History',
    title: 'Research Assignment',
    description: 'Research and write a 2-page report on a significant historical event from the 20th century.',
    dueDate: '2025-03-28',
    assignedBy: 'Mrs. Adams',
    submitted: true,
  },
];

export const exams: Exam[] = [
  {
    id: '1',
    subject: 'Mathematics',
    date: '2025-04-10',
    time: '9:00 AM - 11:00 AM',
    duration: '2 hours',
    venue: 'Room 101',
    topics: ['Algebra', 'Geometry', 'Calculus'],
  },
  {
    id: '2',
    subject: 'Science',
    date: '2025-04-12',
    time: '9:00 AM - 11:00 AM',
    duration: '2 hours',
    venue: 'Room 102',
    topics: ['Physics', 'Chemistry', 'Biology'],
  },
  {
    id: '3',
    subject: 'English',
    date: '2025-04-14',
    time: '9:00 AM - 11:00 AM',
    duration: '2 hours',
    venue: 'Room 103',
    topics: ['Literature', 'Grammar', 'Comprehension'],
  },
  {
    id: '4',
    subject: 'History',
    date: '2025-04-16',
    time: '9:00 AM - 11:00 AM',
    duration: '2 hours',
    venue: 'Room 104',
    topics: ['Ancient History', 'Modern History', 'World Wars'],
  },
];

export const attendance: Attendance[] = [
  {
    date: '2025-03-01',
    status: 'present',
  },
  {
    date: '2025-03-02',
    status: 'present',
  },
  {
    date: '2025-03-03',
    status: 'absent',
  },
  {
    date: '2025-03-04',
    status: 'present',
  },
  {
    date: '2025-03-05',
    status: 'late',
    subject: 'Mathematics',
  },
  {
    date: '2025-03-06',
    status: 'present',
  },
  {
    date: '2025-03-07',
    status: 'present',
  },
];

export const currentUser = users[0]; // Default to student view